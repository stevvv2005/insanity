"""PLACEHOLDER : remplace ce fichier par le vrai bot Discord Sentinelle (étape 3).

Contrat attendu (voir docs/INTEGRATION.md) :
  - /ping <service> <token>  -> GET http://ops-api:8080/ping?service=<service>
  - /audit <id_message>      -> la faille de permission de l'étape 3
Les secrets sont lus au runtime depuis les variables d'environnement (jamais depuis l'image).
"""
import time

if __name__ == "__main__":
    print("Sentinelle (stub) démarré — remplacer par le bot réel")
    while True:
        time.sleep(60)
