"""Vérifie la présence du .env au build (c'est ce qui justifie le COPY)."""
import pathlib, sys

env = pathlib.Path("/app/.env")
if not env.exists():
    sys.exit("healthcheck: .env manquant")
keys = [l.split("=", 1)[0] for l in env.read_text().splitlines() if "=" in l]
print("healthcheck OK, clés:", ", ".join(keys))
