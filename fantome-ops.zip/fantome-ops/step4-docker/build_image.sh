#!/usr/bin/env bash
# Construit sentinelle:1.0 et l'exporte dans out/sentinelle.tar
set -euo pipefail
cd "$(dirname "$0")"
ROOT="$(cd .. && pwd)"
set -a; source "$ROOT/secrets.env"; set +a

CTX="$(mktemp -d)"
trap 'rm -rf "$CTX"' EXIT
cp -r Dockerfile requirements.txt bot "$CTX/"
cat > "$CTX/.env" <<ENVEOF
SIGNING_KEY=$SIGNING_KEY
OPS_API_URL=$OPS_API_URL
STEP4_FLAG=$STEP4_FLAG
ENVEOF

DOCKER_BUILDKIT=1 docker build --no-cache --provenance=false --sbom=false \
  --build-arg KEY_PREVIEW="${SIGNING_KEY:0:4}" -t sentinelle:1.0 "$CTX"

mkdir -p "$ROOT/out"
docker save sentinelle:1.0 -o "$ROOT/out/sentinelle.tar"
echo "OK out/sentinelle.tar"
echo "À vérifier : python solve/step4_extract_layers.py out/sentinelle.tar"
