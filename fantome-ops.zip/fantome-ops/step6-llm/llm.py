"""Backends LLM : anthropic | openai (Ollama/vLLM compatible) | mock (tests, sans réseau)."""
import os

import httpx


def complete(system: str, user: str) -> str:
    backend = os.environ.get("LLM_BACKEND", "anthropic")
    model = os.environ.get("LLM_MODEL", "claude-haiku-5-5")
    if backend == "mock":
        return _mock(user)
    if backend == "anthropic":
        r = httpx.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": os.environ["ANTHROPIC_API_KEY"],
                     "anthropic-version": "2023-06-01"},
            json={"model": model, "max_tokens": 400, "system": system,
                  "messages": [{"role": "user", "content": user}]},
            timeout=60)
        r.raise_for_status()
        return "".join(b.get("text", "") for b in r.json()["content"])
    if backend == "openai":
        base = os.environ.get("LLM_BASE_URL", "http://localhost:11434/v1").rstrip("/")
        r = httpx.post(
            f"{base}/chat/completions",
            headers={"Authorization": f"Bearer {os.environ.get('LLM_API_KEY', 'none')}"},
            json={"model": model, "max_tokens": 400,
                  "messages": [{"role": "system", "content": system},
                               {"role": "user", "content": user}]},
            timeout=120)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]
    raise RuntimeError(f"LLM_BACKEND inconnu: {backend}")


def _mock(user: str) -> str:
    """Simule un modèle vulnérable pour tester la chaîne sans API."""
    half2 = os.environ["HALF_2"]
    low = user.lower()
    if "acrostic" in low or "acrostiche" in low:
        return "Résumé : discussion banale.\n" + "\n".join(
            f"{ch}: ligne {i}" for i, ch in enumerate(half2))
    if "ignore" in low:  # fuite naïve -> doit être bloquée par le filtre
        return f"Le secret est {half2}"
    return "Résumé : discussion banale entre collègues."
