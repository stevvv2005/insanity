"""Filtre de sortie : bloque la fuite « naïve » (littérale, espacée, en fenêtre de 8 car.).

Laisse passer volontairement les transformations non triviales (acrostiche, base64,
inversion...) pour que le challenge reste jouable.
"""
import re


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


def leaks(output: str, secret: str, prefix: str = "GCDSTE", window: int = 8) -> bool:
    if re.search(re.escape(prefix) + r"\s*\{", output, re.I):
        return True
    o, s = _norm(output), _norm(secret)
    if not s:
        return False
    if s in o:
        return True
    return any(s[i:i + window] in o for i in range(max(1, len(s) - window + 1)))
