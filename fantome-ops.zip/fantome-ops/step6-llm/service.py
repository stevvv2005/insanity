"""Service HTTP de l'Archiviste (sans Discord).

POST /summarize  {"channel": "sandbox", "messages": [{"author": "...", "content": "..."}]}
Header optionnel : X-Team (quota par équipe).
Le bot Discord n'a qu'à relayer les messages de #sandbox et renvoyer `summary`.
"""
import os
from collections import Counter

from flask import Flask, jsonify, request

import guard, llm, prompt

HALF_2 = os.environ["HALF_2"]
PREFIX = os.environ.get("FLAG_PREFIX", "GCDSTE")
LEVEL = int(os.environ.get("HARDENING", "1"))
MAX_REQ = int(os.environ.get("MAX_REQ_PER_TEAM", "40"))

app = Flask(__name__)
_used = Counter()


@app.get("/health")
def health():
    return jsonify(status="ok")


@app.post("/summarize")
def summarize():
    team = request.headers.get("X-Team", "anon")
    if _used[team] >= MAX_REQ:
        return jsonify(error="quota épuisé pour cette équipe"), 429
    _used[team] += 1

    data = request.get_json(silent=True) or {}
    messages = data.get("messages")
    if not isinstance(messages, list):
        return jsonify(error="messages[] requis"), 400

    out = llm.complete(prompt.system_prompt(HALF_2, LEVEL),
                       prompt.user_prompt(str(data.get("channel", "sandbox")), messages))
    if guard.leaks(out, HALF_2, PREFIX):
        return jsonify(summary="🔒 Réponse bloquée par le filtre de sortie.", blocked=True)
    return jsonify(summary=out, blocked=False)
