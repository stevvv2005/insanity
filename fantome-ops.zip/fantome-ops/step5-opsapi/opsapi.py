"""ops-api (étape 5) — service interne volontairement vulnérable.

Faille voulue : /ping vérifie l'allowlist sur la valeur BRUTE, puis normalise
(unquote + normpath) AVANT de router -> « health/../internal/keyshard ».
"""
import base64, hashlib, hmac, os, posixpath, time, urllib.parse
from collections import defaultdict, deque

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from flask import Flask, jsonify, request

SIGNING_KEY = os.environ["SIGNING_KEY"].encode()
KEY_DATE = os.environ["KEY_DATE"]
HALF_1 = os.environ["HALF_1"]
STEP5_FLAG = os.environ["STEP5_FLAG"]
RATE_PER_MIN = int(os.environ.get("RATE_PER_MIN", "60"))
ALLOWED = {"health", "status", "metrics"}
STARTED = time.time()

app = Flask(__name__)
_hits = defaultdict(deque)
_counter = {"requests": 0}


def sign(user: str, exp: int) -> str:
    return hmac.new(SIGNING_KEY, f"{user}.{exp}".encode(), hashlib.sha256).hexdigest()


def verify_token(token: str) -> bool:
    try:
        user, exp, sig = token.split(".")
        return int(exp) > time.time() and hmac.compare_digest(sig, sign(user, int(exp)))
    except (ValueError, AttributeError):
        return False


def _auth_ok() -> bool:
    h = request.headers.get("Authorization", "")
    return h.startswith("Bearer ") and verify_token(h[7:].strip())


def _rate_limited() -> bool:
    ip, now = request.remote_addr or "?", time.time()
    q = _hits[ip]
    while q and now - q[0] > 60:
        q.popleft()
    q.append(now)
    return len(q) > RATE_PER_MIN


@app.before_request
def _guard():
    _counter["requests"] += 1
    if _rate_limited():
        return jsonify(error="rate limited"), 429


# ---- handlers internes ------------------------------------------------------
def h_health():
    return {"status": "ok"}


def h_status():
    return {"service": "ops-api", "version": "1.4.2", "uptime_s": int(time.time() - STARTED)}


def h_metrics():
    return {"requests": _counter["requests"]}


def h_keyshard():
    key = hashlib.sha256(f"keyshard:{KEY_DATE}".encode()).digest()
    nonce = os.urandom(12)
    ct = AESGCM(key).encrypt(nonce, HALF_1.encode(), b"keyshard-v1")
    return {
        "flag": STEP5_FLAG,
        "alg": "AES-256-GCM",
        "aad": "keyshard-v1",
        "kdf": "sha256('keyshard:' + YYYY-MM-DD)",
        "shard": base64.b64encode(nonce + ct).decode(),
    }


ROUTES = {"health": h_health, "status": h_status, "metrics": h_metrics,
          "internal/keyshard": h_keyshard}


# ---- routes publiques -------------------------------------------------------
@app.get("/health")
def health():
    return jsonify(h_health())


@app.get("/ping")
def ping():
    if not _auth_ok():
        return jsonify(error="invalid or missing token"), 401
    raw = request.args.get("service", "")
    # BUG VOULU : allowlist vérifiée avant normalisation
    if raw.split("/")[0] not in ALLOWED:
        return jsonify(error="service not allowed"), 403
    path = posixpath.normpath(urllib.parse.unquote(raw)).lstrip("/")
    handler = ROUTES.get(path)
    if handler is None:
        return jsonify(error="unknown service"), 404
    return jsonify(handler())


@app.get("/internal/<path:p>")
def internal_direct(p):
    return jsonify(error="internal only"), 403
