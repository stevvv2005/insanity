# Le Fantôme du #ops — partie non-Discord

Chaîne séquentielle en 6 étapes. Ce dépôt contient **tout sauf Discord** : chaque étape a son
code, sa solution (`solve/`) et ses tests.

| Étape | Contenu | Statut |
|---|---|---|
| 1 | Faux export Discord (snowflakes) | **à faire** (Discord) |
| 2 | Stégano zero-width + base32 | ✅ `step2-stego/` |
| 3 | Bot Sentinelle (`/audit`, `/ping`) | **à faire** (Discord) — stub dans `step4-docker/bot/` |
| 4 | Image Docker + secret dans une couche | ✅ `step4-docker/` |
| 5 | ops-api (HMAC + bypass d'allowlist) | ✅ `step5-opsapi/` |
| 6 | Archiviste LLM (service HTTP) | ✅ `step6-llm/` — colle Discord à faire |

Les parties Discord se branchent via le contrat décrit dans `docs/INTEGRATION.md`.

## Démarrage

```bash
pip install flask cryptography httpx requests pytest gunicorn
make secrets          # génère secrets.env depuis le flag (jamais commité)
make step2            # out/step2_status.txt à coller dans l'export (étape 1)
make test             # 9 tests : stégano, couches Docker, ops-api, filtre, Archiviste, flag
make image            # out/sentinelle.tar (nécessite Docker)
make dev              # ops-api :8080 et archiviste :8081 en local
```

Solutions : `solve/step2_decode.py`, `step4_extract_layers.py`, `step5.py`, `step6_attempt.py`.

## Chaîne de clés

```
date (étape 1, snowflake) ──► mot de passe = sha256(seed:date)[:16]   (étape 2)
mot de passe ──► jeton /audit de Sentinelle (étape 3, contrat INTEGRATION.md)
sentinelle.tar ──► SIGNING_KEY + ops-api (étape 4)
SIGNING_KEY ──► jeton HMAC ──► bypass allowlist ──► /internal/keyshard (étape 5)
keyshard chiffré AES-GCM avec sha256('keyshard:'+date) ──► moitié 1
Archiviste (injection indirecte) ──► moitié 2          (étape 6)
flag = PREFIX{ moitié_1 _ moitié_2 }
```

## Règles de sécurité de l'organisateur

- `secrets.env` est ignoré par Git : ne le publie jamais, ne le colle pas dans Discord.
- Chaque service ne reçoit que ses secrets (voir `infra/docker-compose.yml`).
- `docs/WRITEUP.md` contient les solutions : ne le publie qu'après le CTF.
- `HARDENING` (0/1/2) règle la difficulté de l'Archiviste ; teste ton modèle avant le jour J.
- Avant de lancer : `docker history` de ton image, vérifie qu'aucune info réelle (chemins, user) n'y figure.
