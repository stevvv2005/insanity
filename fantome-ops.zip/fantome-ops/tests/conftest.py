import os, pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent

# Valeurs de test (indépendantes de secrets.env)
os.environ.update({
    "SIGNING_KEY": "ab" * 32,
    "KEY_DATE": "2025-11-17",
    "HALF_1": "t3st_h4lf_0n3",
    "HALF_2": "t3st_h4lf_tw0",
    "FLAG_PREFIX": "GCDSTE",
    "STEP5_FLAG": "GCDSTE{step5_deadbeef}",
    "LLM_BACKEND": "mock",
    "HARDENING": "1",
    "MAX_REQ_PER_TEAM": "5",
})
for sub in ("step2-stego", "step5-opsapi", "step6-llm", "solve", "tools"):
    sys.path.insert(0, str(ROOT / sub))
