#!/usr/bin/env python3
"""Produit out/step2_status.txt (le statut « vide ») et out/step2_status.json."""
import json, pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from envfile import load_env
from encode import encode


def build_payload(env: dict) -> str:
    return json.dumps({
        "seed": env["STEGO_SEED"],
        "bot_id": env["SENTINELLE_BOT_ID"],
        "flag": env["STEP2_FLAG"],
        "note": "pw = sha256(seed + ':' + YYYY-MM-DD)[:16]",
    }, separators=(",", ":"))


if __name__ == "__main__":
    env = load_env(ROOT / "secrets.env")
    hidden = encode(build_payload(env))
    out = ROOT / "out"
    out.mkdir(exist_ok=True)
    (out / "step2_status.txt").write_text(hidden, encoding="utf-8")
    (out / "step2_status.json").write_text(json.dumps(
        {"custom_status": {"text": hidden, "emoji_name": "👻"}}, ensure_ascii=False, indent=2),
        encoding="utf-8")
    print(f"OK out/step2_status.* ({len(hidden)} caractères invisibles)")
