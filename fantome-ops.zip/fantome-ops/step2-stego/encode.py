"""Étape 2 : JSON -> base32 -> bits -> caractères zero-width.

0 = U+200B, 1 = U+200C, séparateur d'octet = U+200D.
"""
import base64, sys

ZERO, ONE, SEP = "\u200b", "\u200c", "\u200d"


def encode(text: str) -> str:
    b32 = base64.b32encode(text.encode()).decode()
    return SEP.join(
        "".join(ONE if b == "1" else ZERO for b in format(ord(c), "08b")) for c in b32
    )


def decode(zw: str) -> str:
    zw = "".join(c for c in zw if c in (ZERO, ONE, SEP))
    b32 = "".join(
        chr(int(chunk.replace(ZERO, "0").replace(ONE, "1"), 2))
        for chunk in zw.split(SEP) if chunk
    )
    return base64.b32decode(b32).decode()


if __name__ == "__main__":
    print(encode(" ".join(sys.argv[1:])))
