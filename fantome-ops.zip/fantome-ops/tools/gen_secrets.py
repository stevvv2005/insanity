#!/usr/bin/env python3
"""Génère secrets.env (jamais commité) à partir du flag final.

Usage: python tools/gen_secrets.py --flag 'GCDSTE{d1sc0rd_gh0st_1n_th3_sh3ll_4nd_th3_l1ar}'
"""
import argparse, datetime, hashlib, os, pathlib, re, secrets, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent


def split_flag(flag: str):
    """Coupe le corps du flag sur une frontière de mot (milieu de la liste de mots)."""
    m = re.fullmatch(r"([A-Za-z0-9]+)\{(.+)\}", flag)
    if not m:
        sys.exit("Flag invalide : attendu PREFIX{...}")
    prefix, body = m.groups()
    words = body.split("_")
    if len(words) < 2:
        sys.exit("Le corps du flag doit contenir au moins un '_' pour être coupé.")
    mid = len(words) // 2
    return prefix, "_".join(words[:mid]), "_".join(words[mid:])


def derive_password(seed: str, date: str) -> str:
    return hashlib.sha256(f"{seed}:{date}".encode()).hexdigest()[:16]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--flag", required=True)
    ap.add_argument("--date", default="2025-11-17",
                    help="date réelle révélée par le snowflake incohérent (étape 1)")
    ap.add_argument("--out", default=str(ROOT / "secrets.env"))
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()

    datetime.date.fromisoformat(a.date)
    out = pathlib.Path(a.out)
    if out.exists() and not a.force:
        sys.exit(f"{out} existe déjà (utilise --force pour régénérer).")

    prefix, h1, h2 = split_flag(a.flag)
    seed = secrets.token_hex(4)
    inter = lambda n: f"{prefix}{{step{n}_{secrets.token_hex(4)}}}"

    lines = [
        f"FLAG={a.flag}",
        f"FLAG_PREFIX={prefix}",
        f"HALF_1={h1}",
        f"HALF_2={h2}",
        f"KEY_DATE={a.date}",
        f"SIGNING_KEY={secrets.token_hex(32)}",
        f"STEGO_SEED={seed}",
        f"STEGO_PASSWORD={derive_password(seed, a.date)}",
        "SENTINELLE_BOT_ID=000000000000000000",
        f"STEP2_FLAG={inter(2)}",
        f"STEP4_FLAG={inter(4)}",
        f"STEP5_FLAG={inter(5)}",
        "OPS_API_URL=http://ops-api:8080",
        "LLM_BACKEND=anthropic",
        "LLM_MODEL=claude-haiku-5-5",
        "LLM_BASE_URL=http://ollama:11434/v1",
        "ANTHROPIC_API_KEY=",
        "HARDENING=1",
        "MAX_REQ_PER_TEAM=40",
    ]
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    os.chmod(out, 0o600)
    print(f"OK {out} écrit")
    print(f"  moitié 1 = {h1}\n  moitié 2 = {h2}")


if __name__ == "__main__":
    main()
