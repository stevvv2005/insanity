#!/usr/bin/env python3
"""Solution étape 4 : parcourt les couches d'un `docker save` et affiche les .env
(y compris ceux supprimés plus tard par un whiteout .wh.).
Usage: step4_extract_layers.py sentinelle.tar
"""
import io, json, sys, tarfile


def scan(tar_path):
    found, whiteouts = [], []
    with tarfile.open(tar_path) as outer:
        manifest = json.load(outer.extractfile("manifest.json"))
        for image in manifest:
            for layer in image["Layers"]:
                blob = outer.extractfile(layer).read()
                with tarfile.open(fileobj=io.BytesIO(blob)) as lt:
                    for m in lt.getmembers():
                        base = m.name.rsplit("/", 1)[-1]
                        if base.startswith(".wh."):
                            whiteouts.append((layer, m.name))
                        elif m.isfile() and base in (".env", "config.yml"):
                            found.append((layer, m.name, lt.extractfile(m).read().decode(errors="replace")))
    return found, whiteouts


if __name__ == "__main__":
    found, whiteouts = scan(sys.argv[1])
    for layer, name, content in found:
        print(f"--- {name}  (couche {layer[:20]}…)\n{content}")
    for layer, name in whiteouts:
        print(f"[whiteout] {name} supprimé dans {layer[:20]}…")
