#!/usr/bin/env python3
"""Solution étape 2 : décode le statut invisible, dérive le mot de passe.
Usage: step2_decode.py status.txt 2025-11-17
"""
import base64, hashlib, json, pathlib, sys

ZERO, ONE, SEP = "\u200b", "\u200c", "\u200d"


def decode(zw):
    zw = "".join(c for c in zw if c in (ZERO, ONE, SEP))
    b32 = "".join(chr(int(c.replace(ZERO, "0").replace(ONE, "1"), 2)) for c in zw.split(SEP) if c)
    return base64.b32decode(b32).decode()


def password(seed, date):
    return hashlib.sha256(f"{seed}:{date}".encode()).hexdigest()[:16]


if __name__ == "__main__":
    payload = json.loads(decode(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")))
    print(payload)
    print("mot de passe =", password(payload["seed"], sys.argv[2]))
